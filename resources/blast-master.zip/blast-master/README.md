##Blast (2.0.0)

**Docs**  
[julian.com/research/blast](http://julian.com/research/blast)

**Quickstart**

```sh
npm install blast-text
```

```sh
bower install blast-text
```

**Frameworks**  
Both jQuery and Zepto are fully supported.

**Browsers**  
All major browsers are supported. Back to IE6.

**Credits**  
Development sponsored by Stripe: https://stripe.com/blog/open-source-retreat-grantees.

====

[MIT License](LICENSE). © Julian Shapiro (http://twitter.com/shapiro).
